#User Creation

import os
import modules.firstsetup as firstsetup
import modules.login as login

if os.path.exists("Files\\user.dat")==False:
    firstsetup.main()
else:
    login.main()


