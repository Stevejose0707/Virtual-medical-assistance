import pickle
f=open("user.dat","rb")
print(pickle.load(f))
f.close()