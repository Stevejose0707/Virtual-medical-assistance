#from difflib import diff_bytes
import pickle
import modules.mainprogram as mainprogram
from datetime import date
def main():

    def adduser():
        with open("Files\\user.dat","rb") as f:
            user_list=pickle.load(f)
        with open("Files\\signin.dat","rb") as f:
            signin_list=pickle.load(f)
        if len(signin_list)==0:
            user_id=0
        else:
            user_id=signin_list[-1][0]+1
        username=input("Enter UserName: ")
        user_email=input("Enter EmailId: ")
        day=int(input("Enter Your Day of Birth:"))
        Month=int(input("Enter Your Month(Number) of Birth:"))
        year=int(input("Enter Your year of Birth:"))
        dob=(day,Month,year)
        height=float(input("Enter your height in cm :"))
        weight=float(input("Enter you weight in kg :"))
        password=input("Enter a password for you account")
        print("The following data has been entered:")
        print(f"Name: {username}")
        print(f"dob: {dob}")
        print(f"height: {height}")
        print(f"Weight: {weight}")
        print("Please remeber your user id:")
        print("_______#######__________\n")
        print(f"User Id: {user_id}\n")
        print("_______#######__________")
        user_list.append([[user_id,username],dob,height,weight,user_email])
        signin_list.append([user_id,password])
        
        with open("Files\\height.dat","rb") as f:
            height_list=pickle.load(f)
            height_list.append([user_id,[[height,str(date.today())]]])
        with open("Files\\height.dat","wb") as f:
            pickle.dump(height_list,f)

        with open("Files\\weight.dat","rb") as f:
            weight_list=pickle.load(f)
            weight_list.append([user_id,[[weight,str(date.today())]]])
        with open("Files\\weight.dat","wb") as f:
            pickle.dump(weight_list,f)
        with open("Files\\user.dat","wb") as f:
            pickle.dump(user_list,f)
        with open("Files\\user.dat","rb") as f:
            print(pickle.load(f))

        with open("Files\\signin.dat","wb") as f:
            pickle.dump(signin_list,f)
        menu()



    def menu():
        with open("Files\\user.dat","rb") as f:
            user_list=pickle.load(f)
        with open("Files\\signin.dat","rb") as f:
            signin_list=pickle.load(f)
        print(signin_list)
        while True:
            print("""

            Press Appropriate Number for selection:

            1. Login
            2. Sign Up
            3. Exit


            """)
            user_selection=int(input("Enter your choice: "))
            if user_selection not in [1,2,3]:
                print("No such Option \n")

            elif user_selection==2:
                adduser(signin_list,user_list)
            elif user_selection==1:
                user_username=int(input("Enter UserId: "))
                user_userpassword=input("Enter password: ")
                
                chk=[user_username,user_userpassword]
                if chk in signin_list:
                    with open("Files\\current_user.dat","w") as f:
                        f.write(str(user_username))
                        mainprogram.main(user_username)
                        break
                        
                else:
                    print("User Not Found")
                    
            elif user_selection==3:
                break

    print(123)
    with open("Files\\user.dat","rb") as f:
        user_list=pickle.load(f)
    with open("Files\\signin.dat","rb") as f:
        signin_list=pickle.load(f)
    print(signin_list)
    print(user_list)
    if len(signin_list)==0:
        adduser()
    else:
        menu()

    
    