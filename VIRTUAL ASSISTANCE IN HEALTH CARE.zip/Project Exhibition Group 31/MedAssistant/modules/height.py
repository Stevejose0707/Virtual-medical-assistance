import matplotlib.pyplot as plt
import pickle
from datetime import date
from datetime import datetime



def current_height(userId):

    with open("Files\\height.dat","rb") as f:
        height_list=pickle.load(f)
    for i in height_list:
        if i[0]==userId:
            heightList=i
            break
    return heightList[-1][-1]

def average_increase(userId):
    
    with open("Files\\height.dat","rb") as f:
        height_list=pickle.load(f)
    for i in height_list:
        if i[0]==userId:
            heightList=i
    avg=0
    for i in range(len(heightList[-1])):
        avg+=heightList[-1][i]
    avg=avg/len(heightList[-1])
    return avg

def plotter(userId):
    
    values_height=[]
    values_date=[]
    with open("Files\\height.dat","rb") as f:
        height_list=pickle.load(f)
    for i in height_list:
        if i[0]==userId:
            heightList=i
            break
    for i in heightList[-1]:
        values_height.append(i[0])
        values_date.append(datetime.strptime(i[1]))
        plt.plot(values_date,values_height)
def addheight(userId):
    
    with open("Files\\height.dat","rb") as f:
        height_list=pickle.load(f)
    for i in range(len(height_list)):
        if height_list[i][0]==userId:
            heightList=height_list[i]
            height_list.pop(i)
            break
    new_height=float(input("Enter NewhWeigt: "))
    new_date=str(date.now)
    heightList[-1].append([new_height,new_date])
    height_list.append(heightList)
    with open("Files\\height.dat","wb") as f:
        pickle.dump(height_list,f)