#MedReminder

import pickle

def status(userId):

    reminder="NO"

    #userId
    with open("Files\\meds.dat","rb") as f:
        meds_list=pickle.load(f)

    medlist=None

    #checking whether the user has med reminder
    for i in meds_list:
        if i[0]==userId:
            medslist=i
            reminder="YES",medlist
            break
    return reminder



def FinderReminder(userId):
    with open("Files\\meds.dat","rb") as f:
        meds_list=pickle.load(f)
    remind=status()
    if remind=="NO":
        print("No Existing Record")
    else:
        s,medList=remind
        for i in range(len(medList)):
            if i==0:
                pass
            else:
                print(medList[i][0])
                print("     Mornining",medList[i][1][0])
                print("     Afternoon",medList[i][1][1])
                print("     Night    ",medList[i][1][2])
                print("_________________________________")
        
def EditReminder(userId):
    
    with open("Files\\meds.dat","r") as f:
        meds_list=pickle.load(f)
    reminder=status()
    if reminder=="NO":
        print("No Existing Record")
    else:
        s,medList=reminder
        for i in range(len(medList)):
            if i==0:
                pass
            else:
                print("No: ",i)
                print(medList[i][0])
                print("     Mornining",medList[i][1][0])
                print("     Afternoon",medList[i][1][1])
                print("     Night    ",medList[i][1][2])
                print("_________________________________")
    user_selection=int(input("Enter The Choice: "))
    if user_selection>len(medList)-1:
        print("Invalid Selection")
    else:
        print("""

        Press Appropriate Number for selection:

       1. Delete Entire Record
       2.Edit Record
       3.Exit

        """)

        sel=int(input("Enter Your Selection: "))
        if sel==1:
            i=user_selection
            medList.pop(i)
        elif sel==2:
            i=user_selection
            print("No: ",i)
            print(medList[i][0])
            print("     Mornining",medList[i][1][0])
            print("     Afternoon",medList[i][1][1])
            print("     Night    ",medList[i][1][2])
            print("_________________________________")
            
            print("""

            Press Appropriate Number for selection:

            1. Morning
            2. Afternoon
            3. Night
            4.Exit


            """)
            sel2=int(input("Enter Choice: "))
            if sel2==1:
                medList[i][1][0]=int(input("Enter New number: "))
            if sel2==2:
                medList[i][1][1]=int(input("Enter New number: "))
            if sel2==3:
                medList[i][1][2]=int(input("Enter New number: "))
            if sel2==4:
                pass
            for i in range(len(meds_list)):
                if meds_list[i][0]==userId:
                    meds_list.pop(i)
                    meds_list.append(medList)
                    with open("Files\\meds.dat","wb") as f:
                        pickle.dump(meds_list,f)
                    break
def AddReminders():
    with open("Files\\current_user.dat","r") as f:
        userId=f.read()
        userId=int(userId)
    with open("Files\\meds.dat","r") as f:
        meds_list=pickle.load(f)
    reminder=status()
    if reminder=="NO":
        print("No Existing Record")
        medList=[userId]
        meds=input("Enter Medicine Name: ")
        mrng=int(input("Enter Dosage For Morining: "))
        aftn=int(input("Enter Dosage For AfterNoon: "))
        even=int(input("Enter Dosage For Evening: "))
        medList.append([meds,[mrng,aftn,even]])
        meds_list.append(medList)
        with open("Files\\meds.dat","wb") as f:
            pickle.dump(meds_list,f)
    else:
        s,medList=reminder
        for i in range(len(medList)):
            if i==0:
                pass
            else:
                print(medList[i][0])
                print("     Mornining",medList[i][1][0])
                print("     Afternoon",medList[i][1][1])
                print("     Night    ",medList[i][1][2])
                print("_________________________________")
        meds=input("Enter Medicine Name: ")
        mrng=int(input("Enter Dosage For Morining: "))
        aftn=int(input("Enter Dosage For AfterNoon: "))
        even=int(input("Enter Dosage For Evening: "))
        medList.append([meds,[mrng,aftn,even]])
        for i in range(len(meds_list)):
            if meds_list[i][0]==userId:
                meds_list.pop(i)
                meds_list.append(medList)
                with open("Files\\meds.dat","wb") as f:
                    pickle.dump(meds_list,f)
                break
       
def medremindermenu(userId):
    while True:
        print("""

            Press Appropriate Number for selection:

        1.Find Your Existing Reminders
        2.Edit your Existing Reminders
        3.Add Reminders
        4. Exit


            """)
        user_selection=int(input("Enter Your Choice: "))
        if user_selection not in [1,2,3,4,5]:
            print("Not an existing Choice")

        elif user_selection==1:
            FinderReminder(userId)
        elif user_selection==2:
            EditReminder(userId)
        elif user_selection==3:
            AddReminders(userId)
        elif user_selection==4:
            break
        elif user_selection==5:
            break


