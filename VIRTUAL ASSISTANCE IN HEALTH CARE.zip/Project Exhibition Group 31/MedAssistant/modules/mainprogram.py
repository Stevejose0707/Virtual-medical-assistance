#from collections import UserList
from glob import glob
import modules.MedReminderSender as mrs
import modules.medReminder as mr
import modules.SpeechEngine as se
import modules.height as height
import modules.weight as weight
import modules.weather as weather
import modules.wiki as wiki
import pickle
from datetime import datetime

def main(userId):
    def medicine():
        stat=mr.status(userId)
        if str(type(stat))=="<class 'str'>":
            s="Have a great Day ahead. You have no medicines schedule for today"
        else:
            stat,medList=mr.status()
            s="Your medicines for today \n"
            for i in range(len(medList)):
                if i==0:
                    pass
                else:
                    s=s+(medList[i][0])+'\n'
                    s=s+"     Mornining"+str(medList[i][1][0])+'\n'
                    s=s+"     Afternoon"+str(medList[i][1][1])+'\n'
                    s=s+"     Night    "+str(medList[i][1][2])+'\n'
                    s=s+"_________________________________"
        return s
    #Greetings and inital information 

    """global userId
    with open("Files\\current_user.dat","r") as f:
        userId=str(f.read())
        print(1)
        userId+="1"
        print(userId)
        u=""
        for i in range(len(userId)-1):
            u+=str(userId[i])"""


    hour=datetime.now().hour
    if hour>=3 and hour<12:
        se.speak("Good Morning")
    elif hour>=12 and hour<16:
        se.speak("Good Afternoon")
    elif hour>=16 and hour<=24:
        se.speak("Have a pleasant Evening")

    with open("Files\\user.dat","rb") as f:
        user_list=pickle.load(f)
        for i in user_list:
            if i[0]==userId:
                print(userId)
                global user_data
                user_data=i[1]
                break
    with open("Files\\meds.dat","rb") as f:
        meds_list=pickle.load(f)
        for i in meds_list:
            if i[0]==userId:
                medsList=i[1]
                break
    with open("Files\\height.dat","rb") as f:
        height_list=pickle.load(f)
        for i in height_list:
            if i[0]==userId:
                heightList=i[1]
                break
    with open("Files\\weight.dat","rb") as f:
        weight_list=pickle.load(f)
        for i in weight_list:
            if i[0]==userId:
                weightList=i[1]
                break
    with open("Files\\bodytemp.dat","rb") as f:
        bodytemp_list=pickle.load(f)

    def bmi(h,w):
        h=h/100
        h=h**2
        b=w/h
        if b<18.4:
            s="Underweight"
        elif b>18.5 and b<25:
            s="Normal"
        elif b>25 and b<39.9:
            s="overweight"
        elif b>40:
            s="obese"
        return b,s

    se.speak("Status Update For You")
    userId=0
    with open("Files\\user.dat","rb") as f:
        user_list=pickle.load(f)
        for i in user_list:
            if i[0][0]==userId:
            
                user_data=i
                break
    with open("Files\\height.dat","rb") as f:
        height_list=pickle.load(f)
        for i in height_list:
            print(i)
            if i[0]==userId:
                heightList=i[1]
                break
    with open("Files\\weight.dat","rb") as f:
        weight_list=pickle.load(f)
        for i in weight_list:
            if i[0]==userId:
                weightList=i[1]
                break
    with open("Files\\bodytemp.dat","rb") as f:
        bodytemp_list=pickle.load(f)
    se.speak(f"Your last recorded weight was{weight.current_weight(userId)}")
    se.speak(f"Your last recorded height was{height.current_height(userId)}")
    se.speak("The update For connecting your Device for temperature and other bodily readings wiill be released in stable 2.0 version")
    #sending medicine reminder

    mrs.mail_alert("Your reminder for Medicine",medicine(),user_data[-1])
    se.speak("your medicine reminder for the day is sent")
    keyboard=True
    while True:

        print("""
                        ________________########____MENU____########________________

                        1. Weight Related Menu
                        2. Height Related Menu
                        3. Medicine Related Menu
                        4. Weather 
                        5. Wikipedia
                        6. Toggle To switch between Voice control and keyboard
                        7. Exit


        """)
        if keyboard:
            select=int(input("Enter Choice: "))
            if select not in [1,2,3,4,5,6,7]:
                pass
            elif select==1:
                while True:
                    print("""
                        ________________########____Weight MENU____########________________

                        1. Current Weight
                        2. Average weight since first entry
                        3. Graphical View of your weight
                        4. Add new Entry 
                        5. Exit


                        """)
                    subelect=int(input("Enter Choice: "))
                    if subelect not in [1,2,3,4,5]:
                        print("Invalid option")
                        pass
                    elif subelect==1:
                        weight.current_weight(userId)
                    elif subelect==2:
                        weight.average_increase(userId)
                    elif subelect==3:
                        weight.plotter(userId)
                    elif subelect==4:
                        weight.addweight(userId)   
                    elif subelect==5:
                        break         
            elif select==2:
                while True:
                    print("""
                        ________________########____Height MENU____########________________

                        1. Current height
                        2. Average height since first entry
                        3. Graphical View of your height
                        4. Add new Entry 
                        5. Exit


                        """)
                    subelect=int(input("Enter Choice: "))
                    if subelect not in [1,2,3,4,5]:
                        print("Invalid option")
                        pass
                    elif subelect==1:
                        height.current_height(userId)
                    elif subelect==2:
                        height.average_increase(userId)
                    elif subelect==3:
                        height.plotter(userId)
                    elif subelect==4:
                        height.addheight(userId)   
                    elif subelect==5:
                        break
            elif select==3:
                mr.medremindermenu(userId)
            elif select==4:
                t,c=weather.main()
                se.speak(f"The temperature is {t} and the current condition is{c}")
            elif select==5:
                wiki.search(input("Enter your Topic to search: ")) 
            elif select==6:
                se.speak("The toggle Voice command work for now only in the main menu the feature will be implemented in submenus in the next update")
                se.speak("Voice control has been activated")
                keyboard=False
            elif select==7:
                break 
        else:
            se.speak("Say which option you want:")
            select=se.recog()
            if select=="some error occured!":
                se.speak("Some error occured please try again or toggle")
            else:
                try:
                    select=int(select)
                
                    if select not in [1,2,3,4,5,6,7]:
                        pass
                    elif select==1:
                        while True:
                            print("""
                                ________________########____Weight MENU____########________________

                                1. Current Weight
                                2. Average weight since first entry
                                3. Graphical View of your weight
                                4. Add new Entry 
                                5. Exit


                                """)
                            subelect=int(input("Enter Choice: "))
                            if subelect not in [1,2,3,4,5]:
                                print("Invalid option")
                                pass
                            elif subelect==1:
                                weight.current_weight(userId)
                            elif subelect==2:
                                weight.average_increase(userId)
                            elif subelect==3:
                                weight.plotter(userId)
                            elif subelect==4:
                                weight.addweight(userId)   
                            elif subelect==5:
                                break         
                    elif select==2:
                        while True:
                            print("""
                                ________________########____Height MENU____########________________

                                1. Current height
                                2. Average height since first entry
                                3. Graphical View of your height
                                4. Add new Entry 
                                5. Exit


                                """)
                            subelect=int(input("Enter Choice: "))
                            if subelect not in [1,2,3,4,5]:
                                print("Invalid option")
                                pass
                            elif subelect==1:
                                height.current_height(userId)
                            elif subelect==2:
                                height.average_increase(userId)
                            elif subelect==3:
                                height.plotter(userId)
                            elif subelect==4:
                                height.addheight(userId)   
                            elif subelect==5:
                                break
                    elif select==3:
                        mr.medremindermenu()
                    elif select==4:
                        t,c=weather.main()
                        se.speak(f"The temperature is {t} and the current condition is{c}")
                    elif select==5:
                        wiki.search(input("Enter your Topic to search: ")) 
                    elif select==6:
                        se.speak("The toggle Voice command work for now only in the main menu the feature will be implemented in submenus in the next update")
                        se.speak("Voice control has been activated")
                        keyboard=False
                    elif select==7:
                        break
                except:
                    se.speak("Some error occured please try again or toggle")
#main()