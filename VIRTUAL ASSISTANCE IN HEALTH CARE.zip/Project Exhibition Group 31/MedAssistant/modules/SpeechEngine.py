from email.mime import audio
import pyttsx3
import speech_recognition as sr

#initiating speaker
def speak(text):
    engine=pyttsx3.init('sapi5')
    voices=engine.getProperty('voices')
    rate = engine.getProperty('rate')
    engine.setProperty('rate', 130)
    engine.setProperty('voice','voices[1].id')
    engine.say(text)
    engine.runAndWait()
    print(text)
    return text
#recognition initiation
def recog():
    r=sr.Recognizer() 
    with sr.Microphone()as source:
        r.adjust_for_ambient_noise(source,duration=0.5)
        print("Listening......")
        speak("Listening")
        audio=r.listen(source)
        try:
            str=r.recognize_google(audio,language="en-GB").lower()
            return str
        except:
	        return "some error occurred!"