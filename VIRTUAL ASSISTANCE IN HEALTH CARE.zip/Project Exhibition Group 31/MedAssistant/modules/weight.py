import matplotlib.pyplot as plt
import pickle
from datetime import date
from datetime import datetime



def current_weight(userId):
    with open("Files\\weight.dat","rb") as f:
        weight_list=pickle.load(f)
    for i in weight_list:
        if i[0]==userId:
            weightList=i
            break
    return weightList[-1][-1]

def average_increase(userId):
    
    
    with open("Files\\weight.dat","rb") as f:
        weight_list=pickle.load(f)
    for i in weight_list:
        if i[0]==userId:
            weightList=i
    avg=0
    for i in range(len(weightList[-1])):
        avg+=weightList[-1][i]
    avg=avg/len(weightList[-1])
    return avg

def plotter(userId):
    
    values_weight=[]
    values_date=[]
    with open("Files\\weight.dat","rb") as f:
        weight_list=pickle.load(f)
    for i in weight_list:
        if i[0]==userId:
            weightList=i
            break
    for i in weightList[-1]:
        values_weight.append(i[0])
        values_date.append(datetime.strptime(i[1]))
        plt.plot(values_date,values_weight)
def addweight(userId):
    
    with open("Files\\weight.dat","rb") as f:
        weight_list=pickle.load(f)
    for i in range(len(weight_list)):
        if weight_list[i][0]==userId:
            weightList=weight_list[i]
            weight_list.pop(i)
            break
    new_weight=float(input("Enter New Weigt: "))
    new_date=str(date.now)
    weightList[-1].append([new_weight,new_date])
    weight_list.append(weightList)
    with open("Files\\weight.dat","wb") as f:
        pickle.dump(weight_list,f)
