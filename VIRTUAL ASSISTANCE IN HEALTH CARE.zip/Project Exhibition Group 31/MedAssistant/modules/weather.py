import requests
def weathernow(city_name):

    k=f"http://api.weatherapi.com/v1/current.json?key=d9fd9522024e47f6b5712137203009&q={city_name}"
        
    data2=requests.get(k).json()
    current_condition=data2["current"]["condition"]['text']
    current_temperature=str(data2["current"]["temp_c"])
    current_condition_icon=data2["current"]["condition"]['icon']
    return (current_condition,current_temperature)
def main():
    return weathernow(input("Enter Your City:"))