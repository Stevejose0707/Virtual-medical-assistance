import pickle


def main():
    l=[]
    with open("Files\\user.dat","wb") as f:
        pickle.dump(l,f)
    with open("Files\\meds.dat","wb") as f:
        pickle.dump(l,f)
    with open("Files\\height.dat","wb") as f:
        pickle.dump(l,f)
    with open("Files\\weight.dat","wb") as f:
        pickle.dump(l,f)
    with open("Files\\bodytemp.dat","wb") as f:
        pickle.dump(l,f)
    with open("Files\\signin.dat","wb") as f:
        pickle.dump(l,f)
main()