import pyttsx3
import wikipedia
import random
def speak(text):
    engine=pyttsx3.init('sapi5')
    voices=engine.getProperty('voices')
    engine.setProperty('voice','voices[0].id')
    rate = engine.getProperty('rate')
    engine.setProperty('rate', 135)
    engine.say(text)
    engine.runAndWait()
def search(sea):

    try:

        speak(wikipedia.summary(sea,sentences=5))
    except wikipedia.DisambiguationError as e:
        speak("there is a lot of choices i have picked you one")
        cho=[]
        for i in e.options:
            cho.append(i)
        while True:
            k=random.choice(e.options)
            try:
                speak(wikipedia.summary(k,sentences=4))
            except wikipedia.DisambiguationError:
                cho.pop(k)
                continue
                
    except wikipedia.exceptions.PageError:
        speak("No Such record")
    except Exception as e:
        pass
