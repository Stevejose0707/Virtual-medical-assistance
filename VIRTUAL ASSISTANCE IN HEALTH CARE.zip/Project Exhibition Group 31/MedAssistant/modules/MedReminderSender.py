from distutils.command.install_egg_info import to_filename
from http import server
import smtplib
from email.message import EmailMessage

def mail_alert(subject, body, to):
    msg=EmailMessage()
    msg.set_content(body)
    msg['subject']= subject
    msg['to']= to

    user = "modules.project22@gmail.com"
    msg['from']=user
    password= "kkoecxsgkgqlqpqw"

    server=smtplib.SMTP("smtp.gmail.com",587)
    server.starttls()
    server.login(user,password)
    server.send_message(msg)
    server.quit()

